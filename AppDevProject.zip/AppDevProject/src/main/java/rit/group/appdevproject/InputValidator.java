/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rit.group.appdevproject;

/**
 *
 * @author Romo
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidator {

    public static boolean isValidUsername(String username) {
        // Username should contain only letters, numbers, underscores, and hyphens
        return username != null && username.matches("^[a-zA-Z0-9_-]+$");
    }

    /*public static boolean isValidEmail(String email) {
        // Email validation using a simple regex
        // This is a basic example; consider using a more sophisticated validation library
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return email != null && matcher.matches();
    }

    public static boolean isValidUserType(String userType) {
        // User type should be either 'user' or 'admin'
        return userType != null && (userType.equals("user") || userType.equals("admin"));
    }*/

    public static boolean isValidPassword(String password) {
        // Password should be at least 8 characters long and contain at least one digit, one uppercase letter, and one special character
        String passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$";
        return password != null && password.matches(passwordRegex);
    }
}

