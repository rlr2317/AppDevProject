/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package rit.group.appdevproject;

/**
 *
 * @author Romo
 */
import com.google.gson.Gson;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import static spark.Spark.*;
public class Login {




    public static void main(String[] args) {
        
        initDatabase();

        // API endpoint for user registration
        post("localhost:3306/app_dev", (req, res) -> {
            res.type("application/json");

            String firstName = req.queryParams("firstName");
            String lastName = req.queryParams("lastName");
            String mail = req.queryParams("mail");
            String userType = req.queryParams("userType");
            int valid = Integer.parseInt(req.queryParams("valid"));
            String password = req.queryParams("password");

            // Validate user input
            if (!InputValidator.isValidUsername(firstName) || !InputValidator.isValidUsername(lastName)
                    || !InputValidator.isValidPassword(password)) {
                res.status(400);
                return new Gson().toJson(new ApiResponse("Invalid input"));
            }

            // Insert user into the database
            try (Connection connection = DatabaaseManager.getConnection()) {
                String sql = "INSERT INTO users (FirstName, LastName, mail, User_type, Valid, Password) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, firstName);
                    statement.setString(2, lastName);
                    statement.setString(3, mail);
                    statement.setString(4, userType);
                    statement.setInt(5, valid);
                    statement.setString(6, password);
                    statement.executeUpdate();
                }
                res.status(201); // Created
                return new Gson().toJson(new ApiResponse("User registered successfully"));
            } catch (SQLException e) {
                e.printStackTrace();
                res.status(500); // Internal Server Error
                return new Gson().toJson(new ApiResponse("Error registering user"));
            }
        });


        // Stop the Spark server
        awaitInitialization();
        stop();
    }

    private static void initDatabase() {
        try (Connection connection = DatabaaseManager.getConnection()) {
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


