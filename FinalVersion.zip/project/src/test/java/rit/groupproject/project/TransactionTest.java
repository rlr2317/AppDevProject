package rit.groupproject.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

public class TransactionTest {

    @Test
    public void testGetId() {
        Transaction instance = new Transaction();
        assertNull(instance.getId());
    }

    @Test
    public void testSetId() {
        Long id = 123L;
        Transaction instance = new Transaction();
        instance.setId(id);
        assertEquals(id, instance.getId());
    }

    @Test
    public void testGetUserId() {
        Transaction instance = new Transaction();
        assertEquals(0, instance.getUserId());
    }

    @Test
    public void testSetUserId() {
        int userId = 456;
        Transaction instance = new Transaction();
        instance.setUserId(userId);
        assertEquals(userId, instance.getUserId());
    }

    @Test
    public void testGetCarId() {
        Transaction instance = new Transaction();
        assertEquals(0, instance.getCarId());
    }

    @Test
    public void testSetCarId() {
        int carId = 789;
        Transaction instance = new Transaction();
        instance.setCarId(carId);
        assertEquals(carId, instance.getCarId());
    }

    @Test
    public void testGetTransactionDate() {
        Transaction instance = new Transaction();
        assertNull(instance.getTransactionDate());
    }

    @Test
    public void testSetTransactionDate() {
        LocalDateTime transactionDate = LocalDateTime.now();
        Transaction instance = new Transaction();
        instance.setTransactionDate(transactionDate);
        assertEquals(transactionDate, instance.getTransactionDate());
    }
}
