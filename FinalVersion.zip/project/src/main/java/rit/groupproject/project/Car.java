/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rit.groupproject.project;

import jakarta.persistence.*;
import java.io.Serializable;
import jakarta.persistence.Entity;

/**
 *
 * @author Romo
 */
@Entity
@Table(name = "cars")
public class Car implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @javax.persistence.Id
    private Long id;

    @Column(name = "Brand")
    private String brand;
    
    @Column(name = "Km")
    private int km;
    
    @Column(name = "Price")
    private double price;
    
    @Column(name = "Color")
    private String color;

    @Enumerated(EnumType.STRING)
    private FuelType fuel;

    @Enumerated(EnumType.STRING)
    private GearShiftType gearShift;

    @Column(name = "Sold")
    private int sold;

    public Car() {
        // Default constructor for JPA
    }

    public Car(String brand, int km, double price, String color, FuelType fuel, GearShiftType gearShift, int sold) {
        this.brand = brand;
        this.km = km;
        this.price = price;
        this.color = color;
        this.fuel = fuel;
        this.gearShift = gearShift;
        this.sold = sold;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getKm() {
        return km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public FuelType getFuel() {
        return fuel;
    }

    public void setFuel(FuelType fuel) {
        this.fuel = fuel;
    }

    public GearShiftType getGearShift() {
        return gearShift;
    }

    public void setGearShift(GearShiftType gearShift) {
        this.gearShift = gearShift;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    // Enum types
    public enum FuelType {
        petrol, diesel, electric, gasoline
    }

    public enum GearShiftType {
        manual, automatic
    }
}

