/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package rit.groupproject.project;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


/**
 *
 * @author Romo
 */
public class CarTest {
    
    public CarTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testGetBrand() {
        System.out.println("getBrand");
        Car instance = new Car();
        String expResult = "Toyota";
        instance.setBrand(expResult);
        String result = instance.getBrand();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetBrand() {
        System.out.println("setBrand");
        String brand = "Toyota";
        Car instance = new Car();
        instance.setBrand(brand);
        String result = instance.getBrand();
        assertEquals(brand, result);
    }

    @Test
    public void testGetKm() {
        System.out.println("getKm");
        Car instance = new Car();
        int expResult = 50000;
        instance.setKm(expResult);
        int result = instance.getKm();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetKm() {
        System.out.println("setKm");
        int km = 50000;
        Car instance = new Car();
        instance.setKm(km);
        int result = instance.getKm();
        assertEquals(km, result);
    }

    @Test
    public void testGetPrice() {
        System.out.println("getPrice");
        Car instance = new Car();
        double expResult = 25000.0;
        instance.setPrice(expResult);
        double result = instance.getPrice();
        assertEquals(expResult, result, 0.01); // Delta for double comparison
    }

    @Test
    public void testSetPrice() {
        System.out.println("setPrice");
        double price = 25000.0;
        Car instance = new Car();
        instance.setPrice(price);
        double result = instance.getPrice();
        assertEquals(price, result, 0.01);
    }

    @Test
    public void testGetColor() {
        System.out.println("getColor");
        Car instance = new Car();
        String expResult = "Blue";
        instance.setColor(expResult);
        String result = instance.getColor();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetColor() {
        System.out.println("setColor");
        String color = "Blue";
        Car instance = new Car();
        instance.setColor(color);
        String result = instance.getColor();
        assertEquals(color, result);
    }

    @Test
    public void testGetFuel() {
        System.out.println("getFuel");
        Car instance = new Car();
        Car.FuelType expResult = Car.FuelType.petrol;
        instance.setFuel(expResult);
        Car.FuelType result = instance.getFuel();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetFuel() {
        System.out.println("setFuel");
        Car.FuelType fuel = Car.FuelType.petrol;
        Car instance = new Car();
        instance.setFuel(fuel);
        Car.FuelType result = instance.getFuel();
        assertEquals(fuel, result);
    }

    @Test
    public void testGetGearShift() {
        System.out.println("getGearShift");
        Car instance = new Car();
        Car.GearShiftType expResult = Car.GearShiftType.automatic;
        instance.setGearShift(expResult);
        Car.GearShiftType result = instance.getGearShift();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetGearShift() {
        System.out.println("setGearShift");
        Car.GearShiftType gearShift = Car.GearShiftType.automatic;
        Car instance = new Car();
        instance.setGearShift(gearShift);
        Car.GearShiftType result = instance.getGearShift();
        assertEquals(gearShift, result);
    }

    @Test
    public void testGetSold() {
        System.out.println("getSold");
        Car instance = new Car();
        int expResult = 0;
        instance.setSold(expResult);
        int result = instance.getSold();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetSold() {
        System.out.println("setSold");
        int sold = 0;
        Car instance = new Car();
        instance.setSold(sold);
        int result = instance.getSold();
        assertEquals(sold, result);
    }
}

    
