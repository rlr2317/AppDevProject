/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rit.groupproject.project;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import javax.sql.DataSource;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

/**
 *
 * @author Romo
 */
@RestController
@RequestMapping("/api")
public class ApiControl {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private CarService carService;

    @Autowired
    private UserRepository UserRepository;

    @Autowired
    private CarRepository carRepository;

    @GetMapping("/ping")
    public String ping() {
        return "Pong! The API is up and running.";
    }

    @GetMapping("/checkDatabaseConnection")
    public String checkDatabaseConnection() {
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
            return "Database connection successful!";
        } catch (SQLException e) {
            return "Database connection failed. Error: " + e.getMessage();
        } finally {

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {

                }
            }
        }
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestHeader("mail") @Valid @Pattern(regexp = "^[A-Za-z0-9+_.-]+@(.+)$", message = "Invalid email format") String mail,
            @RequestHeader("password") @Valid @Pattern(regexp = "^[A-Za-z0-9+_.-]+@(.+)$", message = "Invalid email format") String password) {
        Optional<User> optionalUser = UserRepository.findByMailAndPassword(mail, password);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            String firstName = user.getFirstName();
            LoginResponse response = new LoginResponse(true, "Login successful for user! ", firstName);
            return ResponseEntity.ok(response);
        } else {
            LoginResponse response = new LoginResponse(false, "Invalid credentials for user. Try again", null);
            return ResponseEntity.status(401).body(response);
        }
    }

    @GetMapping("/allcars")
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

    @GetMapping("/brand")
    public ResponseEntity<?> getByBrand(@RequestParam("brand") @Valid @NotBlank String brand) {
        List<Car> cars = carRepository.getByBrand(brand);

        if (!cars.isEmpty()) {
            return ResponseEntity.ok(cars);
        } else {
            String errorMessage = "No cars found for the specified brand.";
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", errorMessage));
        }
    }

    @GetMapping("/car_id")
public ResponseEntity<?> findById(@RequestParam("car_id") Long id) {
    try {
        Optional<Car> car = carRepository.findById(id);
        return car.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    } catch (Exception e) {
        String errorMessage = "Invalid car ID format. Please provide a valid car ID.";
        return ResponseEntity.badRequest().body(Collections.singletonMap("error", errorMessage));
    }
}


    @GetMapping("/color")
    public ResponseEntity<?> getByColor(@RequestParam("color") @Valid @NotBlank String color) {
        List<Car> cars = carRepository.getByColor(color);

        if (!cars.isEmpty()) {
            return ResponseEntity.ok(cars);
        } else {
            String errorMessage = "No cars found for the specified color.";
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", errorMessage));
        }
    }

    @GetMapping("/gearShift")
    public ResponseEntity<?> getByGearShift(@RequestParam("gearShift") @Valid @NotNull Car.GearShiftType gearShift) {
        List<Car> cars = carRepository.getByGearShift(gearShift);

        if (!cars.isEmpty()) {
            return ResponseEntity.ok(cars);
        } else {
            String errorMessage = "No cars found for the specified gear shift type.";
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", errorMessage));
        }
    }

    @GetMapping("/fuelType")
    public ResponseEntity<?> getByFuel(@RequestParam("fuel") String fuel) {
        try {
            Car.FuelType fuelType = Car.FuelType.valueOf(fuel.toLowerCase());
            List<Car> cars = carService.getByFuel(fuelType);

            if (!cars.isEmpty()) {
                return ResponseEntity.ok(cars);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (IllegalArgumentException e) {
            String errorMessage = "Invalid fuel type. Please provide a valid fuel type.";
            return ResponseEntity.badRequest().body(Collections.singletonMap("error", errorMessage));
        }
    }

    @PostMapping("/purchaseCar")
    public ResponseEntity<String> purchaseCar(@RequestParam("id") @Valid @Positive Long carId) {
        return carService.purchaseCar(carId);
    }
}
