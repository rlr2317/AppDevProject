/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rit.groupproject.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.http.ResponseEntity;

@Service
public class CarService {
    private final CarRepository carRepository;

    @Autowired
    public CarService(CarRepository carRepository) {
        this.carRepository = carRepository;
    }

    public List<Car> getAllCars() {
        return carRepository.findAll();
    }
    
    public List<Car> getByBrand(String brand){
    return carRepository.getByBrand(brand);
    }
    public List<Car> getByColor(String color) {
        return carRepository.getByColor(color);
    }

    public List<Car> getByGearShift(Car.GearShiftType gearShift) {
        return carRepository.getByGearShift(gearShift);
    }

    public List<Car> getByFuel(Car.FuelType fuel) {
        return carRepository.getByFuel(fuel);
    }
    
    public List<Car> findBySold(int sold){
    return carRepository.findBySold(sold);
    }
    
    public ResponseEntity<String> purchaseCar(Long carId) {
        Optional<Car> optionalCar = carRepository.findById(carId);

        if (optionalCar.isPresent()) {
            Car car = optionalCar.get();

            if (car.getSold() == 0) {
                car.setSold(1); 
                carRepository.save(car);
                return ResponseEntity.ok("Car purchased successfully.");
            } else {
                return ResponseEntity.badRequest().body("Car is not available for purchase.");
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

