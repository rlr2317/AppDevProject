/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rit.groupproject.project;

/**
 *
 * @author Romo
 */
public class LoginResponse {
    private final boolean success;
    private final String message;
    private final String firstName;

    public LoginResponse(boolean success, String message, String firstName) {
        this.success = success;
        this.message = message;
        this.firstName = firstName;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getFirstName() {
        return firstName;
    }
}

