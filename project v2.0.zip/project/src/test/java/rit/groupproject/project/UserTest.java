/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package rit.groupproject.project;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Romo
 */
public class UserTest {
    
    public UserTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

        @Test
    public void testGetId() {
        System.out.println("getId");
        User instance = new User();
        Long expResult = null;
        Long result = instance.getId();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetId() {
        System.out.println("setId");
        Long id = 1L;
        User instance = new User();
        instance.setId(id);
        Long result = instance.getId();
        assertEquals(id, result);
    }

    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        User instance = new User();
        String expResult = "Balta";
        instance.setFirstName(expResult);
        String result = instance.getFirstName();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "Balta";
        User instance = new User();
        instance.setFirstName(firstName);
        String result = instance.getFirstName();
        assertEquals(firstName, result);
    }

    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        User instance = new User();
        String expResult = "Fernandez";
        instance.setLastName(expResult);
        String result = instance.getLastName();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "Fernandez";
        User instance = new User();
        instance.setLastName(lastName);
        String result = instance.getLastName();
        assertEquals(lastName, result);
    }

    @Test
    public void testGetEmail() {
        System.out.println("getEmail");
        User instance = new User();
        String expResult = "baltifg@gmail.com";
        instance.setEmail(expResult);
        String result = instance.getEmail();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetEmail() {
        System.out.println("setEmail");
        String email = "baltifg@gmail.com";
        User instance = new User();
        instance.setEmail(email);
        String result = instance.getEmail();
        assertEquals(email, result);
    }

    @Test
    public void testGetUserType() {
        System.out.println("getUserType");
        User instance = new User();
        String expResult = "Admin";
        instance.setUserType(expResult);
        String result = instance.getUserType();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetUserType() {
        System.out.println("setUserType");
        String userType = "Admin";
        User instance = new User();
        instance.setUserType(userType);
        String result = instance.getUserType();
        assertEquals(userType, result);
    }

    @Test
    public void testIsValid() {
        System.out.println("isValid");
        User instance = new User();
        boolean expResult = true;
        instance.setValid(expResult);
        boolean result = instance.isValid();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetValid() {
        System.out.println("setValid");
        boolean valid = true;
        User instance = new User();
        instance.setValid(valid);
        boolean result = instance.isValid();
        assertEquals(valid, result);
    }

    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        User instance = new User();
        String expResult = "rit2023";
        instance.setPassword(expResult);
        String result = instance.getPassword();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "rit2023";
        User instance = new User();
        instance.setPassword(password);
        String result = instance.getPassword();
        assertEquals(password, result);
    }
    
}
