/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rit.groupproject.project;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Optional;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

/**
 *
 * @author Romo
 */
@RestController
@RequestMapping("/api")
public class ApiControl {
    
    @Autowired
    private DataSource dataSource;
    
    @Autowired
    private UserRepository UserRepository;
            
    @GetMapping("/ping")
    public String ping() {
        return "Pong! The API is up and running.";
    }
    
        @GetMapping("/checkDatabaseConnection")
    public String checkDatabaseConnection() {
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
            return "Database connection successful!";
        } catch (SQLException e) {
            return "Database connection failed. Error: " + e.getMessage();
        } finally {

            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {

                }
            }
        }
    }
    
    @PostMapping("/login")
    public String login(@RequestHeader("email") String email,
                        @RequestHeader("password") String password) {
        if (isValidCredentials(email, password)) {
            return "Login successful for user: " + email;
        } else {
            return "Invalid credentials for user: " + email;
        }
    }
    
    private boolean isValidCredentials(String email, String password) {
    Optional<User> optionalUser;
        optionalUser = UserRepository.findByEmailAndPassword(email, password); 
    return optionalUser.isPresent();
}

}
